/*
	Nome:
		Felipe Araujo Matos - 5968691
		Kleber Yuji Inoue - 8604297
		Leandro Sena Silva - 9193060

	Projeto 1 - ICC2
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "countryTree.h"
#include "countryVector.h"
#include "heapsort.h"

void maxHeapify_population(COUNTRY *c, int n, int root){
	
	int child = (root*2)+1;

	while(child < n){
		if((child + 1 < n) && (c[child+1].population > c[child].population)){
			child = child + 1;
		}

		int parent = (int)((child-1)/2.0);
		if(c[parent].population < c[child].population){
			COUNTRY aux = c[child];
			c[child] = c[parent];
			c[parent] = aux;
			child = (child * 2)+1;// proximo filho esq.
		}
		else break;
	}
}	

void buildMaxHeap_population(COUNTRY *c, int n){
	int i = (int)((n-1)/2.0);
	while(i >= 0){
		maxHeapify_population(c, n, i);
		i--;
	}
}

void heapsort_population(COUNTRY *c, int n){

	buildMaxHeap_population(c, n);

	int t;
	for(t = n; t >= 2; t--){
		COUNTRY aux = c[0];
		c[0] = c[t-1];
		c[t-1] = aux;

		maxHeapify_population(c, t-1, 0);
	}
}

void maxHeapify_area(COUNTRY *c, int n, int root){
	
	int child = (root*2)+1;

	while(child < n){
		if((child + 1 < n) && (c[child+1].area > c[child].area)){
			child = child + 1;
		}

		int parent = (int)((child-1)/2.0);
		if(c[parent].area < c[child].area){
			COUNTRY aux = c[child];
			c[child] = c[parent];
			c[parent] = aux;
			child = (child * 2)+1;// proximo filho esq.
		}
		else break;
	}
}	

void buildMaxHeap_area(COUNTRY *c, int n){
	int i = (int)((n-1)/2.0);
	while(i >= 0){
		maxHeapify_area(c, n, i);
		i--;
	}
}

void heapsort_area(COUNTRY *c, int n){

	buildMaxHeap_area(c, n);

	int t;
	for(t = n; t >= 2; t--){
		COUNTRY aux = c[0];
		c[0] = c[t-1];
		c[t-1] = aux;

		maxHeapify_area(c, t-1, 0);
	}
}

void maxHeapify_name(COUNTRY *c, int n, int root){
	
	int child = (root*2)+1;

	while(child < n){
		if((child + 1 < n) && (strcmp(c[child+1].name, c[child].name) > 0)){
			child = child + 1;
		}

		int parent = (int)((child-1)/2.0);
		if(strcmp(c[parent].name, c[child].name) < 0){
			COUNTRY aux = c[child];
			c[child] = c[parent];
			c[parent] = aux;
			child = (child * 2)+1;// proximo filho esq.
		}
		else break;
	}
}	

void buildMaxHeap_name(COUNTRY *c, int n){
	int i = (int)((n-1)/2.0);
	while(i >= 0){
		maxHeapify_name(c, n, i);
		i--;
	}
}

void heapsort_name(COUNTRY *c, int n){

	buildMaxHeap_name(c, n);

	int t;
	for(t = n; t >= 2; t--){
		COUNTRY aux = c[0];
		c[0] = c[t-1];
		c[t-1] = aux;

		maxHeapify_name(c, t-1, 0);
	}
}