/*
	Nome:
		Felipe Araujo Matos - 5968691
		Kleber Yuji Inoue - 8604297
		Leandro Sena Silva - 9193060

	Projeto 1 - ICC2
*/

#include <stdio.h>
#include <stdlib.h>
#include "countingsort.h"
#include "countryVector.h"
#include "countryTree.h"


COUNTRY *countingsort_area(COUNTRY *c, int n){

	int maior = getMaior(c, n);
	int *aux = (int *)malloc(sizeof(int) * (maior+1));
	COUNTRY *vector = (COUNTRY *)malloc(sizeof(COUNTRY) * n);

	int i;
	for(i = 0; i <= maior; i++){
		aux[i] = 0;
	}

	for(i = 0; i < n; i++){
		aux[c[i].area]++;
	}

	for(i = 1; i <= maior; i++){
		aux[i] += aux[i-1];
	}

	for(i = n-1; i >= 0; i--){
		vector[aux[c[i].area]-1] = c[i];
		aux[c[i].area]--;
	}

	free(aux);

	return vector;
}

int getMaior(COUNTRY *c, int n){
	int i, maior = c[0].area;

	for(i = 0; i < n; i++){
		if(c[i].area > maior) maior = c[i].area;
	}

	return maior;
}