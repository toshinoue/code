/*
	Nome:
		Felipe Araujo Matos - 5968691
		Kleber Yuji Inoue - 8604297
		Leandro Sena Silva - 9193060

	Projeto 1 - ICC2
*/

#ifndef BUSCA_H
#define BUSCA_H value

#include "countryVector.h"
#include "countryTree.h"

int sequential_search_population(COUNTRY *c, int key);

int sequential_search_area(COUNTRY *c, int key);

int sequential_search_name(COUNTRY *c, char *key);

int binary_search_population(COUNTRY *c, int key, int start, int finish);

int binary_search_area(COUNTRY *c, int key, int start, int finish);

int binary_search_name(COUNTRY *c, char *key, int start, int finish);

int interpolation_search_population(COUNTRY *c, int key, int start, int finish);

int interpolation_search_area(COUNTRY *c, int key, int start, int finish);

int interpolation_search_name(COUNTRY *c, char *key, int start, int finish);

#endif