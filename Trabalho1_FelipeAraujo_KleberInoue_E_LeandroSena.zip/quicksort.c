/*
	Nome:
		Felipe Araujo Matos - 5968691
		Kleber Yuji Inoue - 8604297
		Leandro Sena Silva - 9193060

	Projeto 1 - ICC2
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "countryTree.h"
#include "countryVector.h"
#include "quicksort.h"

int quicksort_population_random(COUNTRY *a , int p, int r){
	COUNTRY t;
	if(p < r){
		int v = (rand() % (r-p)) + p;
		COUNTRY pivo = a[v];

		a[v] = a[r];
		a[r] = pivo ;

		int i = p-1;
		int j = r;

		do{
			do{
				i++;
			}while(a[i].population < pivo.population);
			do{
				j--;
			}while((a[j].population > pivo.population) &&(j > p));
			if(i < j){
				t = a[i];
				a[i] = a[j];
				a[j] = t;
			}
		}while(i < j);
		a[r] = a[i];
		a[i] = pivo;

		quicksort_population_random(a, p, i-1);
		quicksort_population_random(a, i+1 , r);
	}

	return 0;
}

int quicksort_area_random(COUNTRY *a , int p, int r){
	COUNTRY t;
	if(p < r){
		int v = (rand() % (r-p)) + p;
		COUNTRY pivo = a[v];

		a[v] = a[r];
		a[r] = pivo ;

		int i = p-1;
		int j = r;

		do{
			do{
				i++;
			}while(a[i].area < pivo.area);
			do{
				j--;
			}while((a[j].area > pivo.area) &&(j > p));
			if(i < j){
				t = a[i];
				a[i] = a[j];
				a[j] = t;
			}
		}while(i < j);
		a[r] = a[i];
		a[i] = pivo;

		quicksort_area_random(a, p, i-1);
		quicksort_area_random(a, i+1 , r);
	}

	return 0;
}

int quicksort_name_random(COUNTRY *a , int p, int r){
	COUNTRY t;
	if(p < r){
		int v = (rand() % (r-p)) + p;
		COUNTRY pivo = a[v];

		a[v] = a[r];
		a[r] = pivo ;

		int i = p-1;
		int j = r;

		do{
			do{
				i++;
			}while(strcmp(a[i].name, pivo.name) < 0);
			do{
				j--;
			}while(strcmp(a[j].name, pivo.name) > 0 &&(j > p));
			if(i < j){
				t = a[i];
				a[i] = a[j];
				a[j] = t;
			}
		}while(i < j);
		a[r] = a[i];
		a[i] = pivo;

		quicksort_name_random(a, p, i-1);
		quicksort_name_random(a, i+1 , r);
	}

	return 0;
}

int quicksort_population_first(COUNTRY *a , int p, int r){
	COUNTRY t;
	if(p < r){
		int v = 1;
		COUNTRY pivo = a[v];

		a[v] = a[r];
		a[r] = pivo ;

		int i = p-1;
		int j = r;

		do{
			do{
				i++;
			}while(a[i].population < pivo.population);
			do{
				j--;
			}while((a[j].population > pivo.population) &&(j > p));
			if(i < j){
				t = a[i];
				a[i] = a[j];
				a[j] = t;
			}
		}while(i < j);
		a[r] = a[i];
		a[i] = pivo;

		quicksort_population_first(a, p, i-1);
		quicksort_population_first(a, i+1 , r);
	}

	return 0;
}

int quicksort_area_first(COUNTRY *a , int p, int r){
	COUNTRY t;
	if(p < r){
		int v = 1;
		COUNTRY pivo = a[v];
		a[v] = a[r];
		a[r] = pivo ;

		int i = p-1;
		int j = r;

		do{
			do{
				i++;
			}while(a[i].area < pivo.area);
			do{
				j--;
			}while((a[j].area > pivo.area) &&(j > p));
			if(i < j){
				t = a[i];
				a[i] = a[j];
				a[j] = t;
			}
		}while(i < j);
		a[r] = a[i];
		a[i] = pivo;

		quicksort_area_first(a, p, i-1);
		quicksort_area_first(a, i+1 , r);
	}

	return 0;
}

int quicksort_name_first(COUNTRY *a , int p, int r){
	COUNTRY t;
	if(p < r){
		int v = 1;

		COUNTRY pivo = a[v];
		a[v] = a[r];
		a[r] = pivo ;

		int i = p-1;
		int j = r;

		do{
			do{
				i++;
			}while(strcmp(a[i].name, pivo.name) < 0);
			do{
				j--;
			}while(strcmp(a[j].name, pivo.name) > 0 &&(j > p));
			if(i < j){
				t = a[i];
				a[i] = a[j];
				a[j] = t;
			}
		}while(i < j);
		a[r] = a[i];
		a[i] = pivo;

		quicksort_name_first(a, p, i-1);
		quicksort_name_first(a, i+1 , r);
	}

	return 0;
}

int quicksort_population_mid(COUNTRY *a , int p, int r){
	COUNTRY t;
	if(p < r){
		int v = (int)((p+r)/2);
		COUNTRY pivo = a[v];
		a[v] = a[r];
		a[r] = pivo;

		int i = p-1;
		int j = r;

		do{
			do{
				i++;
			}while(a[i].population < pivo.population);
			do{
				j--;
			}while((a[j].population > pivo.population) &&(j > p));
			if(i < j){
				t = a[i];
				a[i] = a[j];
				a[j] = t;
			}
		}while(i < j);
		a[r] = a[i];
		a[i] = pivo;

		quicksort_population_mid(a, p, i-1);
		quicksort_population_mid(a, i+1 , r);
	}

	return 0;
}

int quicksort_area_mid(COUNTRY *a , int p, int r){
	COUNTRY t;
	if(p < r){
		int v = (int)((p+r)/2);
		COUNTRY pivo = a[v];
		a[v] = a[r];
		a[r] = pivo;

		int i = p-1;
		int j = r;

		do{
			do{
				i++;
			}while(a[i].area < pivo.area);
			do{
				j--;
			}while((a[j].area > pivo.area) &&(j > p));
			if(i < j){
				t = a[i];
				a[i] = a[j];
				a[j] = t;
			}
		}while(i < j);
		a[r] = a[i];
		a[i] = pivo;

		quicksort_area_mid(a, p, i-1);
		quicksort_area_mid(a, i+1 , r);
	}

	return 0;
}

int quicksort_name_mid(COUNTRY *a , int p, int r){
	COUNTRY t;
	if(p < r){
		int v = (int)((p+r)/2);
		COUNTRY pivo = a[v];
		a[v] = a[r];
		a[r] = pivo;

		int i = p-1;
		int j = r;

		do{
			do{
				i++;
			}while(strcmp(a[i].name, pivo.name) < 0);
			do{
				j--;
			}while(strcmp(a[j].name, pivo.name) > 0 &&(j > p));
			if(i < j){
				t = a[i];
				a[i] = a[j];
				a[j] = t;
			}
		}while(i < j);
		a[r] = a[i];
		a[i] = pivo;

		quicksort_name_mid(a, p, i-1);
		quicksort_name_mid(a, i+1 , r);
	}

	return 0;
}