/*
	Nome:
		Felipe Araujo Matos - 5968691
		Kleber Yuji Inoue - 8604297
		Leandro Sena Silva - 9193060

	Projeto 1 - ICC2
*/

#ifndef HEAPSORT_H
#define HEAPSORT_H value

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "countryTree.h"
#include "countryVector.h"
#include "heapsort.h"

void maxHeapify_population(COUNTRY *c, int n, int root);

void buildMaxHeap_population(COUNTRY *c, int n);

void heapsort_population(COUNTRY *c, int n);

void maxHeapify_area(COUNTRY *c, int n, int root);

void buildMaxHeap_area(COUNTRY *c, int n);

void heapsort_area(COUNTRY *c, int n);

void maxHeapify_name(COUNTRY *c, int n, int root);

void buildMaxHeap_name(COUNTRY *c, int n);

void heapsort_name(COUNTRY *c, int n);

#endif