/*
	Nome:
		Felipe Araujo Matos - 5968691
		Kleber Yuji Inoue - 8604297
		Leandro Sena Silva - 9193060

	Projeto 1 - ICC2
*/

#ifndef COUNTINGSORT_H
#define COUNTINGSORT_H value

#include "countryVector.h"
#include "countryTree.h"

COUNTRY *countingsort_area(COUNTRY *c, int n);

int getMaior(COUNTRY *c, int n);

#endif