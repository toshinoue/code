/*
	Nome:
		Felipe Araujo Matos - 5968691
		Kleber Yuji Inoue - 8604297
		Leandro Sena Silva - 9193060

	Projeto 1 - ICC2
*/

#ifndef QUICKSORT_H
#define QUICKSORT_H value

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "countryTree.h"
#include "countryVector.h"
#include "quicksort.h"

int quicksort_population_random(COUNTRY *a , int p, int r);

int quicksort_area_random(COUNTRY *a , int p, int r);

int quicksort_name_random(COUNTRY *a , int p, int r);

int quicksort_population_first(COUNTRY *a , int p, int r);

int quicksort_area_first(COUNTRY *a , int p, int r);

int quicksort_name_first(COUNTRY *a , int p, int r);

int quicksort_population_mid(COUNTRY *a , int p, int r);

int quicksort_area_mid(COUNTRY *a , int p, int r);

int quicksort_name_mid(COUNTRY *a , int p, int r);

#endif