/*
	Nome:
		Felipe Araujo Matos - 5968691
		Kleber Yuji Inoue - 8604297
		Leandro Sena Silva - 9193060

	Projeto 1 - ICC2
*/

#ifndef COUNTRYVECTOR_H
#define COUNTRYVECTOR_H
#define NCOUNTRY 227

#include <stdio.h>
#include <stdlib.h>
#include "countryVector.h"
#include "countryTree.h"

typedef struct country{
	char *name, *region;
	int population, area;
	float density;
}COUNTRY;

COUNTRY *create_country_list();

void free_country_list(COUNTRY *c);

void print_country(COUNTRY c);

void print_all(COUNTRY *c);

void get_from_file(FILE *fp, COUNTRY *c);


#endif