/*
	Nome:
		Felipe Araujo Matos - 5968691
		Kleber Yuji Inoue - 8604297
		Leandro Sena Silva - 9193060

	Projeto 1 - ICC2
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "countryTree.h"
#include "countryVector.h"

NODE *create_tree(){
	NODE *root = (NODE *)malloc(sizeof(NODE));

	if(root != NULL){
		root->name = NULL;
		root->region = NULL;
		root->left = NULL;
		root->right = NULL;
	}

	return root;
}

NODE *insert(int son, NODE *node, COUNTRY country){
	NODE *new = (NODE *)malloc(sizeof(NODE));

	int aux;
	if(new != NULL){
		aux = strlen(country.name);
		new->name = (char *)malloc(sizeof(char) * aux);
		strcpy(new->name, country.name);

		aux = strlen(country.region);
		new->region = (char *)malloc(sizeof(char) * aux);
		strcpy(new->region, country.region);

		new->population = country.population;
		new->area = country.area;
		new->density = country.density;

		new->left = NULL;
		new->right = NULL;
	}

	if(son == LEFT){
		node->left = new;
	}else{
		node->right = new;
	}

	return new;
}

//Key = population
int insert_abb(NODE *root, COUNTRY country){
	NODE *aux;
	if(root->population > country.population){
		if(root->left != NULL)
			return insert_abb(root->left, country);
		else{
			aux = insert(LEFT, root, country);
			if(aux != NULL) return 1;
		}
	}else{
		if(root->population <= country.population){
			if(root->right != NULL)
				return insert_abb(root->right, country);
			else{
				aux = insert(RIGHT, root, country);
				if(aux != NULL) return 1;
			}
		}
	}

	return 0;
}

void preordem(NODE *root){
	if(root != NULL){
		print_node(root);
		preordem(root->left);
		preordem(root->right);
	}
}

NODE *search_abb(NODE *root, int key){
	if(root == NULL){
		printf("----------KEY NOT FOUNDED----------\n\n");
		return NULL;
	}else{
		if(root->population == key){
			printf("----------KEY FOUNDED----------\n\n");
			return root;
		}else{
			if(root->population > key)
				return search_abb(root->left, key);
			else
				return search_abb(root->right, key);
		}
	}

	return NULL;
}

void free_tree(NODE *root){
	if(root != NULL){
		free_tree(root->left);
		free_tree(root->right);	
	}
}

void free_node(NODE *n){
	if(n->name != NULL) free(n->name);
	if(n->region != NULL) free(n->region);
	free(n);
}

void print_node(NODE *node){
	printf("Country name: %s\n", node->name);
	printf("Region: %s\n", node->region);
	printf("Population: %d\n", node->population);
	printf("Area: %d\n", node->area);
	printf("Density: %.2f\n\n", node->density);
}