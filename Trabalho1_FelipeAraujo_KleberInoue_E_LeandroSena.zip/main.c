/*
	Nome:
		Felipe Araujo Matos - 5968691
		Kleber Yuji Inoue - 8604297
		Leandro Sena Silva - 9193060

	Projeto 1 - ICC2
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "countryVector.h"
#include "countryTree.h"
#include "busca.h"
#include "quicksort.h"
#include "heapsort.h"
#include "countingsort.h"

char *set_string();

void print_menu();

void clrscr();

int main(int argc, char const *argv[]){
	
	FILE *fp = fopen("world.csv", "r");
	if(fp == NULL){
		printf("I cannot open this file\n");
		exit(0);
	}

	COUNTRY *c = create_country_list();
	NODE *root = create_tree();

	get_from_file(fp, c);

	int op, i, key, index;
	char *str;
	NODE *aux;
	double start_t, end_t, total_t;
	do{
		print_menu();
		scanf("%d", &op);
		switch(op){
			case 1:
				printf("INSERCAO SELECIONADO\n\n");
				for(i = 0; i < NCOUNTRY; i++){
					insert_abb(root, c[i]);
				}
				printf("INSERIDO COM SUCESSO!\n");
				break;
			case 2:
				printf("IMPRESSAO DA ARVORE SELECIONADO\n\n");
				preordem(root);
				break;
			case 3:
				printf("BUSCA NA ARVORE SELECIONADO\n\n");
				printf("Digite a chave (int) - populacao:\n");
				scanf("%d", &key);
				aux = search_abb(root, key);

				if(aux != NULL){
					print_node(aux);
					free_node(aux);
				}

				break;
			case 4:
				printf("ORDENACAO QUICKSORT NA POPULACAO SELECIONADO\n\n");

				start_t = clock();
				quicksort_population_random(c, 0, NCOUNTRY-1);
				end_t = clock();
				total_t = (double)(end_t - start_t) * 1000 / CLOCKS_PER_SEC;
				printf("Tempo de execucao - Quicksort Random = %.3lfms\n", total_t);

				start_t = clock();
				quicksort_population_first(c, 0, NCOUNTRY-1);
				end_t = clock();
				total_t = (double)(end_t - start_t) * 1000 / CLOCKS_PER_SEC;
				printf("Tempo de execucao - Quicksort primeiro elemento = %.3lfms\n", total_t);
				
				start_t = clock();
				quicksort_population_mid(c, 0, NCOUNTRY-1);
				end_t = clock();
				total_t = (double)(end_t - start_t) * 1000 / CLOCKS_PER_SEC;
				printf("Tempo de execucao - Quicksort elemento meio = %.3lfms\n\n", total_t);
				
				break;
			case 5:
				printf("ORDENACAO QUICKSORT NA AREA SELECIONADO\n\n");

				start_t = clock();
				quicksort_area_random(c, 0, NCOUNTRY-1);
				end_t = clock();
				total_t = (double)(end_t - start_t) * 1000 / CLOCKS_PER_SEC;
				printf("Tempo de execucao - Quicksort Random = %.3lfms\n", total_t);

				start_t = clock();
				quicksort_area_first(c, 0, NCOUNTRY-1);
				end_t = clock();
				total_t = (double)(end_t - start_t) * 1000 / CLOCKS_PER_SEC;
				printf("Tempo de execucao - Quicksort primeiro elemento = %.3lfms\n", total_t);

				start_t = clock();
				quicksort_area_mid(c, 0, NCOUNTRY-1);
				end_t = clock();
				total_t = (double)(end_t - start_t) * 1000 / CLOCKS_PER_SEC;
				printf("Tempo de execucao - Quicksort elemento meio = %.3lfms\n\n", total_t);
				break;
			case 6:
				printf("ORDENACAO QUICKSORT NO NOME SELECIONADO\n\n");

				start_t = clock();
				quicksort_name_random(c, 0, NCOUNTRY-1);
				end_t = clock();
				total_t = (double)(end_t - start_t) * 1000 / CLOCKS_PER_SEC;
				printf("Tempo de execucao - Quicksort Random elemento = %.3lfms\n", total_t);

				start_t = clock();
				quicksort_name_first(c, 0, NCOUNTRY-1);
				end_t = clock();
				total_t = (double)(end_t - start_t) * 1000 / CLOCKS_PER_SEC;
				printf("Tempo de execucao - Quicksort primeiro elemento = %.3lfms\n", total_t);

				start_t = clock();
				quicksort_name_mid(c, 0, NCOUNTRY-1);
				end_t = clock();
				total_t = (double)(end_t - start_t) * 1000 / CLOCKS_PER_SEC;
				printf("Tempo de execucao - Quicksort elemento meio = %.3lfms\n\n", total_t);
				break;
			case 7:
				printf("ORDENACAO HEAPSORT NA POPULACAO SELECIONADO\n\n");

				start_t = clock();
				heapsort_population(c, NCOUNTRY);
				end_t = clock();
				total_t = (double)(end_t - start_t) * 1000 / CLOCKS_PER_SEC;
				printf("Tempo de execucao - Heapsort = %.3lfms\n", total_t);
				break;
			case 8:
				printf("ORDENACAO HEAPSORT NA AREA SELECIONADO\n\n");

				start_t = clock();
				heapsort_area(c, NCOUNTRY);
				end_t = clock();
				total_t = (double)(end_t - start_t) * 1000 / CLOCKS_PER_SEC;
				printf("Tempo de execucao - Heapsort = %.3lfms\n", total_t);
				break;
			case 9:
				printf("ORDENACAO HEAPSORT NO NOME SELECIONADO\n\n");

				start_t = clock();
				heapsort_name(c, NCOUNTRY);
				end_t = clock();
				total_t = (double)(end_t - start_t) * 1000 / CLOCKS_PER_SEC;
				printf("Tempo de execucao - Heapsort = %.3lfms\n", total_t);
				break;
			case 10:
				printf("ORDENACAO COUNTINGSORT NA AREA SELECIONADO\n\n");

				start_t = clock();
				c = countingsort_area(c, NCOUNTRY);
				end_t = clock();
				total_t = (double)(end_t - start_t) * 1000 / CLOCKS_PER_SEC;
				printf("Tempo de execucao - Countingsort = %.3lfms\n", total_t);
				break;
			case 12:
				printf("BUSCA SEQUENCIAL NA POPULACAO SELECIONADO\n\n");

				printf("Digite a chave(int) para populacao:\n");
				scanf("%d", &key);

				start_t = clock();

				index = sequential_search_population(c, key);

				end_t = clock();
				total_t = (double)(end_t - start_t) * 1000 / CLOCKS_PER_SEC;

				if(index == -1) printf("----------KEY NOT FOUNDED----------\n\n");
				else{
					printf("----------KEY FOUNDED----------\n\n");
					print_country(c[index]);
				}
				
				printf("Tempo de execucao - Busca sequencial = %.3lfms\n", total_t);
				break;
			case 13:
				printf("BUSCA SEQUENCIAL NA AREA SELECIONADO\n\n");

				printf("Digite a chave(int) para populacao:\n");
				scanf("%d", &key);

				start_t = clock();

				index = sequential_search_area(c, key);

				end_t = clock();
				total_t = (double)(end_t - start_t) * 1000 / CLOCKS_PER_SEC;

				if(index == -1) printf("----------KEY NOT FOUNDED----------\n\n");
				else{
					printf("----------KEY FOUNDED----------\n\n");
					print_country(c[index]);
				}
				
				printf("Tempo de execucao - Busca sequencial = %.3lfms\n", total_t);
				break;
			case 14:
				printf("BUSCA SEQUENCIAL NO NOME SELECIONADO\n\n");

				getchar();
				str = set_string();

				start_t = clock();
				index = sequential_search_name(c, str);
				end_t = clock();
				total_t = (double)(end_t - start_t) * 1000 / CLOCKS_PER_SEC;

				if(index == -1) printf("----------KEY NOT FOUNDED----------\n\n");
				else{
					printf("----------KEY FOUNDED----------\n\n");
					print_country(c[index]);
				}
				printf("Tempo de execucao - Busca sequencial = %.3lfms\n", total_t);

				free(str);
				break;
			case 15:
				printf("BUSCA BINARIA NA POPULACAO SELECIONADO\n\n");

				printf("Digite a chave(int) para populacao:\n");
				scanf("%d", &key);

				start_t = clock();
				index = binary_search_population(c, key, 0, NCOUNTRY);
				end_t = clock();
				total_t = (double)(end_t - start_t) * 1000 / CLOCKS_PER_SEC;
				if(index == -1) printf("----------KEY NOT FOUNDED----------\n\n");
				else{
					printf("----------KEY FOUNDED----------\n\n");
					print_country(c[index]);
				}			
				printf("Tempo de execucao - Busca binaria = %.3lfms\n", total_t);
				break;
			case 16:
				printf("BUSCA BINARIA NA AREA SELECIONADO\n\n");

				printf("Digite a chave(int) para area:\n");
				scanf("%d", &key);

				start_t = clock();
				index = binary_search_area(c, key, 0, NCOUNTRY);
				end_t = clock();
				total_t = (double)(end_t - start_t) * 1000 / CLOCKS_PER_SEC;
				if(index == -1) printf("----------KEY NOT FOUNDED----------\n\n");
				else{
					printf("----------KEY FOUNDED----------\n\n");
					print_country(c[index]);
				}

				printf("Tempo de execucao - Busca binaria = %.3lfms\n", total_t);
				break;
			case 17:
				printf("BUSCA BINARIA NO NOME SELECIONADO\n\n");

				getchar();
				str = set_string();

				start_t = clock();
				index = binary_search_name(c, str, 0, NCOUNTRY);
				end_t = clock();
				total_t = (double)(end_t - start_t) * 1000 / CLOCKS_PER_SEC;

				if(index == -1) printf("----------KEY NOT FOUNDED----------\n\n");
				else{
					printf("----------KEY FOUNDED----------\n\n");
					print_country(c[index]);
				}
				printf("Tempo de execucao - Busca binaria = %.3lfms\n", total_t);

				free(str);
				break;
			case 18:
				printf("BUSCA INTERPOLADA NA POPULACAO SELECIONADO\n\n");

				printf("Digite a chave(int) para populacao:\n");
				scanf("%d", &key);

				start_t = clock();
				index = interpolation_search_population(c, key, 0, NCOUNTRY-1);
				end_t = clock();
				total_t = (double)(end_t - start_t) * 1000 / CLOCKS_PER_SEC;

				if(index == -1) printf("----------KEY NOT FOUNDED----------\n\n");
				else{
					printf("----------KEY FOUNDED----------\n\n");
					print_country(c[index]);
				}
				printf("Tempo de execucao - Busca interpolada = %.3lfms\n", total_t);
				break;
			case 19:
				printf("BUSCA INTERPOLADA NA AREA SELECIONADO\n\n");

				printf("Digite a chave(int) para area:\n");
				scanf("%d", &key);

				start_t = clock();
				index = interpolation_search_area(c, key, 0, NCOUNTRY-1);
				end_t = clock();
				total_t = (double)(end_t - start_t) * 1000 / CLOCKS_PER_SEC;

				if(index == -1) printf("----------KEY NOT FOUNDED----------\n\n");
				else{
					printf("----------KEY FOUNDED----------\n\n");
					print_country(c[index]);
				}
				printf("Tempo de execucao - Busca interpolada = %.3lfms\n", total_t);
				break;
			case 20:
				printf("BUSCA INTERPOLADA NO NOME SELECIONADO\n\n");

				getchar();
				str = set_string();

				start_t = clock();
				index = interpolation_search_name(c, str, 0, NCOUNTRY-1);
				end_t = clock();
				total_t = (double)(end_t - start_t) * 1000 / CLOCKS_PER_SEC;
				
				if(index == -1) printf("----------KEY NOT FOUNDED----------\n\n");
				else{
					printf("----------KEY FOUNDED----------\n\n");
					print_country(c[index]);
				}
				printf("Tempo de execucao - Busca interpolada = %.3lfms\n", total_t);
				free(str);
				break;
			case 21:
				print_all(c);
				break;
			case 22:
				clrscr();
			case 0:
				break;
			default:
				printf("Opcao invalida\n");
				break;
		}
	}while(op != 0);

	free_country_list(c);
	free_tree(root);
	fclose(fp);

	return 0;
}

char *set_string(){
	char *str = NULL;
	size_t bytes;

	printf("Digite o nome do pais (string):\n");
	getline(&str, &bytes, stdin);

	int len = strlen(str);
	str[len-1] = '\0';

	return str;
}

void print_menu(){
	printf("---------------------------------------------------------------\n");
	printf("Escolha uma opcao:\n");
	printf("\n");
	printf("1 - Inserir na arvore binaria\n");
	printf("2 - Imprimir a arvore binaria - Necessario que ja tenha sido inserido na arvore\n");
	printf("3 - Buscar na arvore binaria (populacao)\n");
	printf("\n");
	printf("4 - Ordenar o vetor pela POPULACAO - QUICKSORT\n");
	printf("5 - Ordenar o vetor pela AREA - QUICKSORT\n");
	printf("6 - Ordenar o vetor pelo NOME - QUICKSORT\n");
	printf("\n");
	printf("7 - Ordenar o vetor pela POPULACAO - HEAPSORT\n");
	printf("8 - Ordenar o vetor pela AREA - HEAPSORT\n");
	printf("9 - Ordenar o vetor pelo NOME - HEAPSORT\n");
	printf("\n");
	printf("10 - Ordenar o vetor pela AREA - COUNTINGSORT\n");
	printf("\n");
	printf("12 - Busca SEQUENCIAL pela POPULACAO\n");
	printf("13 - Busca SEQUENCIAL pela AREA\n");
	printf("14 - Busca SEQUENCIAL pelo NOME\n");
	printf("\n");
	printf("15 - Busca BINARIA pela POPULACAO\n");
	printf("16 - Busca BINARIA pela AREA\n");
	printf("17 - Busca BINARIA pelo NOME\n");
	printf("\n");
	printf("18 - Busca INTERPOLADA pela POPULACAO\n");
	printf("19 - Busca INTERPOLADA pela AREA\n");
	printf("20 - Busca INTERPOLADA pelo NOME\n");
	printf("\n");
	printf("21 - Imprimir todos os paises\n");
	printf("\n");
	printf("22 - Limpar a tela\n");
	printf("0 - Sair\n");
	printf("---------------------------------------------------------------\n");
}

void clrscr(){
    system("@cls||clear");
}