/*
	Nome:
		Felipe Araujo Matos - 5968691
		Kleber Yuji Inoue - 8604297
		Leandro Sena Silva - 9193060

	Projeto 1 - ICC2
*/

#include <stdio.h>
#include <stdlib.h>
#include "countryVector.h"
#include "countryTree.h"

COUNTRY *create_country_list(){
	COUNTRY *c = (COUNTRY *)malloc(sizeof(COUNTRY) * NCOUNTRY);

	int i;
	for(i = 0; i < NCOUNTRY; i++){
		c[i].name = NULL;
		c[i].region = NULL;
		c[i].population = 0;
		c[i].area = 0;
		c[i].density = 0;
	}

	return c;
}

void free_country_list(COUNTRY *c){
	int i;
	for(i = 0; i < NCOUNTRY; i++){
		free(c[i].name);
		free(c[i].region);
	}

	free(c);
}

void print_country(COUNTRY c){
	printf("Country name: %s\n", c.name);
	printf("Region: %s\n", c.region);
	printf("population: %d\n", c.population);
	printf("Area: %d\n", c.area);
	printf("Density: %.2f\n\n", c.density);
}

void print_all(COUNTRY *c){
	int i;
	for(i = 0; i < NCOUNTRY; i++){
		print_country(c[i]);
	}
}

void get_from_file(FILE *fp, COUNTRY *c){
	int i = 0, aux, fileInt;
	double fileDouble;
	char fileChar;
	for(i = 0; i < NCOUNTRY; i++){
		aux = 0;
		do{
			fscanf(fp, "%c", &fileChar);
			c[i].name = (char *)realloc(c[i].name, sizeof(char) * (aux+1));
			if(fileChar != ',')	c[i].name[aux++] = fileChar;
		}while(fileChar != ',');

		aux = 0;
		do{
			fscanf(fp, "%c", &fileChar);
			c[i].region = (char *)realloc(c[i].region, sizeof(char) * (aux+1));
			if(fileChar != ',')	c[i].region[aux++] = fileChar;
		}while(fileChar != ',');

		fscanf(fp, "%d", &fileInt);
		c[i].population = fileInt;

		fscanf(fp, "%c", &fileChar);

		fscanf(fp, "%d", &fileInt);
		c[i].area = fileInt;

		fscanf(fp, "%c", &fileChar);
		fscanf(fp, "%c", &fileChar);

		aux = 0;
		char *auxString = NULL;
		fileChar = '-';
		do{
			fscanf(fp, "%c", &fileChar);
			auxString = (char *)realloc(auxString, sizeof(int) * (aux+1));
			if(fileChar != '"') {
				if(fileChar == ',') fileChar = '.';
				auxString[aux++] = fileChar;
			}
		}while(fileChar != '"');
		c[i].density = atof(auxString);
		free(auxString);

		//Get '\n'
		fscanf(fp, "%c", &fileChar);
	}
}
