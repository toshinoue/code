/*
	Nome:
		Felipe Araujo Matos - 5968691
		Kleber Yuji Inoue - 8604297
		Leandro Sena Silva - 9193060

	Projeto 1 - ICC2
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "busca.h"
#include "countryVector.h"
#include "countryTree.h"

int sequential_search_population(COUNTRY *c, int key){

	int i;
	//Population
	for(i = 0; i < NCOUNTRY; i++){
		if(c[i].population == key){
			return i;
		}
	}

	return -1;
}
int sequential_search_area(COUNTRY *c, int key){

	int i;

	//area
	for(i = 0; i < NCOUNTRY; i++){
		if(c[i].area == key){
			return i;
		}
	}

	return -1;
}
int sequential_search_name(COUNTRY *c, char *key){

	int i;
	for(i = 0; i < NCOUNTRY; i++){
		if(strcmp(c[i].name, key) == 0){
			return i;
		}
	}

	return -1;
}

int binary_search_population(COUNTRY *c, int key, int start, int finish){
	if(finish > start){
		int med = (int)((start+finish)/2);

		if(c[med].population == key){
			return med;
		}

		if(key > c[med].population)
			return binary_search_population(c, key, med+1, finish);
		else return binary_search_population(c, key, start, med);	
	}

	return -1;
}

int binary_search_area(COUNTRY *c, int key, int start, int finish){
	if(finish > start){
		int med = (int)((start+finish)/2);

		if(c[med].area == key){
			return med;
		}

		if(key > c[med].area)
			return binary_search_area(c, key, med+1, finish);
		else return binary_search_area(c, key, start, med);	
	}

	return -1;
}

int binary_search_name(COUNTRY *c, char *key, int start, int finish){
	if(finish > start){
		int med = (int)((start+finish)/2);
		
		if(strcmp(c[med].name, key) == 0){
			return med;
		}

		if(strcmp(key, c[med].name) > 0)
			return binary_search_name(c, key, med+1, finish);
		else return binary_search_name(c, key, start, med);	
	}

	return -1;
}

int interpolation_search_population(COUNTRY *c, int key, int start, int finish){
	if(finish > start){
		int med = (start + (finish - start) * ((key - c[start].population) / (c[finish].population - c[start].population)));

		if(c[med].population == key){
			return med;
		}

		if(key > c[med].population)
			return interpolation_search_population(c, key, med+1, finish);
		else
			return interpolation_search_population(c, key, start, med);	
	}

	return -1;
}


int interpolation_search_area(COUNTRY *c, int key, int start, int finish){
	if(finish > start){
		int med = (start + (finish - start) * ((key - c[start].area) / (c[finish].area - c[start].area)));

		if(c[med].area == key){
			return med;
		}

		if(key > c[med].area)
			return interpolation_search_area(c, key, med+1, finish);
		else
			return interpolation_search_area(c, key, start, med);	
	}

	return -1;
}

int interpolation_search_name(COUNTRY *c, char *key, int start, int finish){
	if(finish > start){
		int med = (start + (finish - start) * (strcmp(key, c[start].name) / strcmp(c[finish].name, c[start].name)));

		if(strcmp(c[med].name, key) == 0){
			return med;
		}

		if(strcmp(key, c[med].name) > 0)
			return interpolation_search_name(c, key, med+1, finish);
		else
			return interpolation_search_name(c, key, start, med);	
	}	

	return -1;
}