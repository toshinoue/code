/*
	Nome:
		Felipe Araujo Matos - 5968691
		Kleber Yuji Inoue - 8604297
		Leandro Sena Silva - 9193060

	Projeto 1 - ICC2
*/

#ifndef COUNTRYTREE_H
#define COUNTRYTREE_H value

#include <stdio.h>
#include <stdlib.h>
#include "countryVector.h"
#include "countryTree.h"

#define LEFT 0
#define RIGHT 1


typedef struct country COUNTRY;

typedef struct node{
	char *name, *region;
	int population, area;
	float density;
	struct node *left, *right;
}NODE;


NODE *create_tree();

NODE *insert(int son, NODE *node, COUNTRY country);

//Key = population
int insert_abb(NODE *root, COUNTRY country);

void preordem(NODE *root);

NODE *search_abb(NODE *root, int key);

void free_tree(NODE *root);

void free_node(NODE *n);

void print_node(NODE *root);

#endif